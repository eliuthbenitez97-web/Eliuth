PROYECTO ELIUTH - COMPILACION APK

Este proyecto esta preparado para compilarse en GitHub Actions.

Configuracion:
- Java 17
- Gradle 8.7
- Android Gradle Plugin 8.5.2
- compileSdk 35
- Build Tools 35.0.0

El APK de prueba se genera en:
app/build/outputs/apk/debug/app-debug.apk

Si se usa el workflow incluido directamente desde la raiz del proyecto,
no hace falta tener gradle-wrapper.jar porque GitHub Actions instala Gradle 8.7.
