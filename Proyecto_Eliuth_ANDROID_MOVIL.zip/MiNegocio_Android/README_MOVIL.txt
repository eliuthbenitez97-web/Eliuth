PROYECTO ELIUTH — COMPILAR EN ANDROID

1) Instala Android Code Studio desde:
https://github.com/AndroidCSOfficial/android-code-studio/releases

2) Abre Android Code Studio y completa la configuración inicial.

3) En Terminal ejecuta:
idesetup -c

4) Descarga y descomprime este proyecto.

5) Abre la carpeta MiNegocio_Android en Android Code Studio.
   Debe ser la carpeta donde están settings.gradle y build.gradle.

6) Espera la sincronización de Gradle.

7) Pulsa Build/Run y compila la variante Debug.
   O abre Terminal en la raíz del proyecto y ejecuta:
   ./build-apk-android.sh

8) El APK estará en:
app/build/outputs/apk/debug/app-debug.apk

IMPORTANTE:
- No uses una ruta de SDK de Windows/Linux en local.properties.
- La primera compilación necesita Internet para descargar Gradle y dependencias.
- Si Android Code Studio pide instalar API 35, acéptalo.
