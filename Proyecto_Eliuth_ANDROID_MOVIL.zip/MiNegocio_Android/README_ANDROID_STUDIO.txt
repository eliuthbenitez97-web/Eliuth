PROYECTO ELIUTH — Android Studio
================================

1. Descomprime este ZIP.
2. Abre en Android Studio la carpeta MiNegocio_Android.
3. Espera a que termine Gradle Sync y acepte/instale los componentes Android SDK que Android Studio solicite.
4. Ve a Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio mostrará un aviso con el enlace "locate" para abrir el APK.

CONFIGURACIÓN
-------------
- Nombre: Proyecto Eliuth
- applicationId: com.eliiuth.minegocio
- compileSdk: 35
- targetSdk: 35
- minSdk: 23
- Versión: 1.1 (versionCode 2)
- Pantalla vertical.
- Datos locales mediante localStorage.
- Importación de respaldos JSON desde el selector de archivos de Android.
- Exportación de respaldo JSON desde la aplicación.

NOTA SOBRE EL GRADLE WRAPPER
----------------------------
El proyecto incluye gradle/wrapper/gradle-wrapper.properties para fijar Gradle 8.7,
pero este paquete no incluye el binario wrapper porque Android Studio puede descargar
la distribución automáticamente durante la sincronización. No se incluye local.properties
porque la ruta del Android SDK cambia según la computadora.

PARA INSTALAR EN EL TELÉFONO
-----------------------------
Después de Build APK(s), usa el APK debug generado en:
app/build/outputs/apk/debug/app-debug.apk

En Android, habilita la instalación desde la fuente que uses para abrir el APK si el
sistema lo solicita.
