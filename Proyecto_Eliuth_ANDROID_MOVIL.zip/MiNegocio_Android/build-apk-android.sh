#!/system/bin/sh
set -e
cd "$(dirname "$0")"

# Proyecto Eliuth: compilación debug desde un IDE Android con Gradle.
# Android Code Studio/AndroidIDE puede proporcionar su propio aapt2.
# Si existe el aapt2 del entorno, lo pasamos a Gradle.
if [ -x "$HOME/.androidide/aapt2" ]; then
  ./gradlew -Pandroid.aapt2FromMavenOverride="$HOME/.androidide/aapt2" :app:assembleDebug
else
  ./gradlew :app:assembleDebug
fi

echo ""
echo "APK generado:"
echo "$PWD/app/build/outputs/apk/debug/app-debug.apk"
