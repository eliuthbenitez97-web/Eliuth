# Proyecto Eliuth — compilación desde teléfono Android

## Método recomendado: Android Code Studio

Android Code Studio permite abrir proyectos Android basados en Gradle directamente en un teléfono/tableta y tiene soporte para Gradle, JDK 17 y administrador de SDK. El proyecto usa Android Gradle Plugin 8.5.2 y Gradle 8.7, compatibles con el requisito de AGP moderno de Android Code Studio.

### 1. Instalar Android Code Studio

Descárgalo únicamente desde su repositorio oficial de GitHub:
https://github.com/AndroidCSOfficial/android-code-studio/releases

### 2. Preparar el SDK

Abre Android Code Studio y completa su configuración inicial.

En su Terminal instala/actualiza las herramientas del SDK con:

    idesetup -c

Acepta la configuración cuando pregunte.

El proyecto necesita como mínimo Android API 35 porque `compileSdk = 35`.

### 3. Abrir Proyecto Eliuth

1. Descarga este ZIP en el teléfono.
2. Descomprímelo.
3. Abre Android Code Studio.
4. Selecciona **Open/Import Project**.
5. Selecciona la carpeta `MiNegocio_Android` (la carpeta que contiene `settings.gradle`).
6. Espera a que termine la sincronización de Gradle.

No crees otro proyecto. Abre directamente esta carpeta.

### 4. Compilar el APK

Desde la interfaz del IDE usa **Build/Run** y selecciona la variante `debug`.

Si prefieres Terminal, desde la raíz del proyecto ejecuta:

    ./build-apk-android.sh

El APK esperado es:

    app/build/outputs/apk/debug/app-debug.apk

### 5. Instalar

Cuando termine la compilación, abre el APK desde el administrador de archivos del teléfono y autoriza la instalación desde esa fuente si Android lo solicita.

## Si aparece un error de SDK

Comprueba que Android API 35 esté instalado desde el SDK Manager/Terminal. No crees un `local.properties` con una ruta de PC: en Android Code Studio la ruta del SDK pertenece al propio entorno del teléfono.

## Si aparece un error de memoria

Cierra otras aplicaciones y vuelve a compilar. La primera compilación puede tardar porque Gradle descarga dependencias.

## Requisito recomendado del teléfono

- Android 8 o superior recomendado.
- Al menos 4 GB de RAM; 6 GB o más es preferible para compilar proyectos Android.
- Espacio libre suficiente para SDK + cachés + proyecto.
- Internet durante la primera sincronización para descargar Gradle/dependencias.
