PROYECTO ELIUTH — Android Studio

Proyecto Android listo para abrir en Android Studio.
Nombre de la app: Proyecto Eliuth
Version: 1.1
Minimo Android: 6.0 (API 23)
Objetivo: Android 15 (API 35)

INCLUIDO
- Ventas, compras, productos e inventario.
- Gastos, clientes, deudas y pagos parciales.
- Caja, cierre de caja, reportes y estadisticas.
- Calculadora comercial, moneda USD/CUP y calculadora solar.
- Factura/comprobante e impresion mediante el sistema del telefono.
- Respaldo e importacion JSON.
- Datos guardados localmente en el telefono.
- Selector de archivos Android para restaurar respaldos.
- Boton de retroceso Android compatible con la navegacion de la app.
- Proyecto preparado para generar APK desde Android Studio o GitHub Actions.

ABRIR EN ANDROID STUDIO
1. Descomprime este ZIP.
2. Abre la carpeta como proyecto (Open).
3. Espera la sincronizacion de Gradle.
4. Ejecuta en un telefono Android o emulador.
5. Para APK: Build > Build APK(s).

COMPILACION AUTOMATICA
El archivo .github/workflows/build-apk.yml permite compilar un APK debug en GitHub Actions.
No requiere que el usuario tenga Gradle instalado localmente en GitHub.

IMPORTANTE
La informacion se almacena localmente. Usa Exportar respaldo periodicamente.
La app no tiene sincronizacion en la nube ni una cuenta de usuario todavia.
